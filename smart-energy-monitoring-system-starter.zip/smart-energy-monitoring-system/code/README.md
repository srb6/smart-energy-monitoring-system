# Firmware

Add the verified original ESP32 firmware here. The original source file was not available when this repository starter was created, so no working firmware is included yet.

Before publishing firmware, remove Wi-Fi passwords, Blynk auth tokens, API keys, and other credentials.
