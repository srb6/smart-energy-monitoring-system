# Circuit and Wiring

Add the verified circuit diagram, pin mapping, sensor models, relay details, and power-supply information here. Do not publish an unverified wiring diagram as the original circuit.
