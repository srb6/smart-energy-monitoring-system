# Smart Energy Monitoring System

An IoT-based smart energy monitoring and appliance-control project developed for a 30-hour ECE Association hackathon.

## Hackathon Achievement
- **Award:** Second Prize
- **Prize:** ₹1,000
- **Event:** 30-hour ECE Association hackathon

## Project Overview
The project concept combines energy monitoring with connected appliance management. Previously described features include:
- Monitoring electrical energy consumption
- Remote appliance control through the Blynk app
- Phone-gesture-based appliance control
- Vacation Mode for managing appliances while occupants are away
- Theft/unauthorized-activity detection while Vacation Mode is enabled

> **Implementation note:** This repository is being reconstructed because the original source files are currently unavailable. Verify each feature against the actual prototype and add the original code, sensor models, circuit, and screenshots when recovered. Do not treat placeholder files as production-ready firmware.

## Hardware
The project was previously described as ESP32-based with voltage/current sensing. Exact sensor models, relay board, wiring, and power supply still need to be confirmed.

## Software
- ESP32 firmware (to be added/verified)
- Arduino IDE (if used in the original build)
- Blynk IoT (previously described; confirm the actual dashboard configuration)

## System Architecture
Conceptual architecture (verify against the original build):

Electrical measurements → ESP32 → Wi-Fi / IoT dashboard  
ESP32 → relay driver → controlled appliance

## Repository Structure
```text
smart-energy-monitoring-system/
├── README.md
├── code/
│   └── README.md
├── circuit/
│   └── README.md
├── images/
│   └── README.md
└── docs/
    └── README.md
```

## Safety
Mains electricity can cause fatal electric shock and fire. Do not connect an ESP32 or low-voltage sensor board directly to mains wiring. Use properly isolated, appropriately rated measurement modules and relay hardware, enclosure, fusing, and qualified supervision.

## Future Documentation
- [ ] Add verified ESP32 firmware
- [ ] Add circuit diagram and exact component list
- [ ] Add prototype photos and dashboard screenshots
- [ ] Document setup and calibration steps
- [ ] Add a demo video link, if available

## License
No license has been selected yet. Add one only after deciding how others may reuse this work.
